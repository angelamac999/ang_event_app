from django.apps import AppConfig


class EventfinderappConfig(AppConfig):
    name = 'eventFinderApp'
